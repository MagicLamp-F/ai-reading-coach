# 系统架构

## 1. 总体架构

```text
用户
  |
  v
Telegram
  |
  v
OpenClaw Gateway
  |
  v
Python Orchestrator
  |
  +--> SQLite 事实数据库
  |
  +--> Hermes Memory / Reflection
  |
  +--> Search Skill / Tavily / Web
  |
  +--> LLM 推荐生成
  |
  v
OpenClaw -> Telegram 推送结果
```

当前代码先用 Python 实现最小闭环。后续逐步把 Telegram Gateway 和长期记忆反思能力迁移到 OpenClaw 与 Hermes。

## 2. 组件职责

### SQLite：事实层

SQLite 是 source of truth，保存不可丢失的原始事实：

- 推荐记录。
- 用户按钮反馈。
- 原因反馈。
- 自由文本。
- 周期性复盘回答。
- 结构化画像条目。
- 运行日志。
- API 调用和成本记录。

原则：

- 原始事件不被覆盖。
- 画像摘要可以重算。
- 每条画像必须能追溯证据。

### Hermes：长期记忆和反思层

Hermes 负责把事实解释成语义记忆：

- 读取 SQLite 摘要。
- 读取和维护 `USER.md` / `MEMORY.md`。
- 总结长期兴趣和短期关注。
- 识别知识缺口、行动阶段、反感模式。
- 每周生成画像复盘。
- 提出 Skill 或推荐策略的改进建议。

Hermes 不直接替代 SQLite。Hermes 生成的是可解释的语义视图，SQLite 保留事实证据。

### OpenClaw：入口和执行层

OpenClaw 负责 Agent Gateway 能力：

- Telegram channel。
- 用户 session。
- Skill/tool 权限。
- 消息路由。
- 反馈按钮和后续交互。

后续目标是用 OpenClaw 替代当前 Python 自写 `telegram.py` 和 `poller.py` 的部分能力。

### Python Orchestrator：可靠编排层

Python 后端负责确定性流程：

- 每日定时触发。
- 数据库读写。
- 调用 Hermes。
- 调用搜索和模型。
- 记录运行日志。
- 控制 API 调用次数。
- 暴露指标。
- 失败时可重跑、可排查。

它不负责“变聪明”，它负责让闭环可靠发生。

### Skill：行为规范层

Skill 用于沉淀 Agent 的工作方式：

- 如何筛选书籍。
- 如何说明推荐理由。
- 如何解释用户反馈。
- 如何更新用户画像。
- 如何生成复盘问题。

Skill 的更新应先由 Hermes 提出建议，再由用户确认后生效。

## 3. 当前实现与目标架构的关系

当前 Python MVP 已实现：

- SQLite schema。
- 每日推荐 workflow。
- Telegram 推送和按钮反馈。
- 反馈回写画像。
- 7 天复盘基础。
- 日志和基础 metrics。

当前实现暂时代替：

- Hermes 的部分画像规则。
- OpenClaw 的 Telegram Gateway。
- Skill 的部分 prompt 行为。

后续改造方向：

```text
profile.py 的规则总结 -> Hermes reflection
telegram.py / poller.py -> OpenClaw Gateway
硬编码 prompt -> Skill 文件
SQLite 摘要 -> Hermes memory provider / context input
```

## 4. 关键架构原则

### 事实和解释分离

SQLite 保存事实，Hermes 生成解释。解释可以更新，事实必须保留。

### 推荐和建模分离

推荐是交互方式，建模是核心目标。不要只优化推荐命中率。

### 生成和控制分离

模型负责生成主题、推荐和总结；后端负责定时、状态、日志、成本和权限。

### 自动化和人审分离

反馈回写和记忆总结可以自动化。Skill 更新、策略变化和流程调整初期需要人审。

