# 工程化文档索引

这套文档用于把“AI 读书私教系统”从想法整理成可实施、可验证、可迭代的工程项目。

推荐阅读顺序：

1. [项目章程](./00_project_charter.md)：为什么做、做成什么样、边界是什么。
2. [系统架构](./01_system_architecture.md)：SQLite、Hermes、OpenClaw、Python 后端如何分工。
3. [闭环设计](./02_closed_loop_design.md)：推荐、反馈、原因、反思如何形成用户建模闭环。
4. [数据契约](./03_data_contracts.md)：核心数据对象、事件、画像字段和接口边界。
5. [实施路线](./04_implementation_roadmap.md)：从当前 Python MVP 到 Hermes/OpenClaw 融合版的阶段计划。
6. [运行与验收](./05_operations_and_validation.md)：如何运行、观测、验收和复盘。

现有探索文档：

- [推荐反馈驱动的多维用户建模 MVP](../user_modeling_feedback_mvp.md)

