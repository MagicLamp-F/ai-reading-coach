# 运行与验收

## 1. 本地运行

初始化：

```powershell
cd D:\test\ai-reading-coach
copy .env.example .env
python -m app.cli init-db
python -m app.cli seed-profile --file prompts/user_manual.example.md
```

单次运行：

```powershell
python -m app.cli run-daily
python -m app.cli poll-telegram --once
python -m app.cli run-weekly-report
```

常驻运行：

```powershell
python -m app.cli run-scheduler
```

Docker：

```powershell
docker compose up --build -d
```

## 2. 配置项

必填：

```env
TELEGRAM_BOT_TOKEN=
TELEGRAM_CHAT_ID=
OPENAI_API_KEY=
TAVILY_API_KEY=
```

关键控制项：

```env
DATABASE_URL=sqlite:///data/reading_coach.db
DAILY_PUSH_TIME=08:00
TIMEZONE=Asia/Shanghai
MAX_DAILY_SEARCH_CALLS=6
MAX_DAILY_MODEL_CALLS=4
HTTP_TIMEOUT_SECONDS=20
```

## 3. 可观测性

当前系统提供：

- `logs/reading_coach.log`
- `run_logs`
- `cost_logs`
- `/metrics`

需要重点观察：

- 每日任务是否成功。
- Telegram 推送是否成功。
- 反馈是否入库。
- 未处理反馈是否堆积。
- API 调用次数是否超预期。
- 画像条目是否有证据。

基础指标：

```text
reading_coach_profile_items
reading_coach_runs_total
reading_coach_feedback_total
```

## 4. 7 天验收

目标：验证基础闭环是否成立。

检查项：

- 每天是否生成 3 本推荐。
- 每本推荐是否包含系统假设。
- 用户是否完成按钮反馈。
- 是否至少 30% 的反馈包含原因。
- 反馈是否写入 SQLite。
- 画像是否发生可解释变化。
- 7 天复盘是否包含准确观察和系统误解。

通过标准：

```text
推荐完成率 >= 85%
反馈率 >= 60%
原因反馈率 >= 30%
复盘准确观察 >= 3 条
系统误解 >= 1 条
画像条目均有证据来源
```

## 5. 30 天验收

目标：验证系统是否真的帮助用户更了解自己。

检查项：

- 长期兴趣是否有变化曲线。
- 短期关注是否能与实际阶段对应。
- 是否识别出重复出现的知识缺口。
- 是否区分不喜欢主题、已掌握、时机不对和表达不喜欢。
- 是否能总结阅读偏好。
- 是否能指出用户反复回避但可能重要的主题。

通过标准：

```text
用户认为 30 天画像报告明显优于初始说明书
至少 3 条观察让用户觉得“我之前没明确说，但确实如此”
至少 2 条系统误解被记录并修正
推荐策略能基于复盘做一次人审后的调整
```

## 6. 风险与控制

### 画像漂移

风险：单次反馈错误改变长期画像。

控制：

- 单次反馈只做小幅更新。
- 画像区分待验证和稳定。
- 至少 3 条证据后再进入稳定状态。

### 过度打扰

风险：原因反馈和反思问题太多，用户不愿继续使用。

控制：

- 按钮反馈始终最低成本。
- 原因反馈可跳过。
- 每周反思只需回答 1-2 个问题。

### Agent 黑箱总结

风险：Hermes 总结看似合理但缺乏证据。

控制：

- 每条画像必须关联证据。
- SQLite 保留原始事件。
- memory patch 初期人审。

### 成本失控

风险：搜索和模型调用过多。

控制：

- 每日调用上限。
- 成本日志。
- 失败降级。

### Gateway 权限风险

风险：OpenClaw 或 Skill 调用了不该调用的能力。

控制：

- Skill 白名单。
- 不开放敏感账号、支付、文件删除等能力。
- 所有外部动作记录日志。

