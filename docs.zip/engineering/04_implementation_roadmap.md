# 实施路线

## 阶段 0：现状冻结

目标：确认当前 Python MVP 能跑通基础链路。

已完成：

- SQLite 初始化。
- 用户说明书导入。
- 每日推荐 workflow。
- Telegram 推送和按钮反馈框架。
- 反馈回写画像。
- 7 天复盘基础。
- 基础测试。

验收：

- `run-daily` 能生成 3 条推荐。
- 反馈能写入 `feedback_events`。
- `profile_items` 能更新。

## 阶段 1：把推荐改成“假设驱动”

目标：每本推荐都明确说明它在测试哪个用户假设。

改动：

- `recommendations` 增加 `system_hypothesis`。
- `recommendations` 增加 `profile_dimensions`。
- 推荐 prompt 要求输出系统假设。
- Telegram 消息展示系统假设。

验收：

- 每条推荐都能回答“为什么推荐这本书测试用户的哪个维度”。

## 阶段 2：增加原因反馈

目标：让按钮反馈变成可解释信号。

改动：

- `feedback_events` 增加 `reason_code`。
- Telegram 点击按钮后追加原因选择。
- 不同按钮展示不同原因选项。
- 画像更新规则根据 `feedback_type + reason_code` 共同判断。

验收：

- 至少 30% 的反馈包含原因。
- 不感兴趣能区分主题不相关、已掌握、太难、时机不对等情况。

## 阶段 3：扩展多维画像

目标：从兴趣模型升级成多维用户模型。

改动：

- 扩展 `ProfileItem.category`。
- 增加知识缺口、行动阶段、能量状态、探索倾向、自我叙事等维度。
- 更新 `build_profile_context()`，按维度分组输出画像。
- 每条画像保留证据来源。

验收：

- 7 天复盘至少覆盖 5 个画像维度。
- 每条画像能追溯到推荐或反馈证据。

## 阶段 4：接入 Hermes 记忆反思

目标：让 Hermes 负责长期记忆和周期性反思。

改动：

- 从 SQLite 导出周期摘要。
- 生成 Hermes 可读上下文。
- Hermes 输出 `USER.md` / `MEMORY.md` patch。
- 新增 `reflections` 表保存反思结果。
- 初期 memory patch 需要人工确认。

验收：

- 每 7 天能生成一份 Hermes 反思结果。
- 反思能输出准确观察、系统误解和下周问题。
- `USER.md` / `MEMORY.md` 可版本化更新。

## 阶段 5：接入 OpenClaw Gateway

目标：用 OpenClaw 承担 Telegram 和 Skill 执行入口。

改动：

- 将 Telegram channel 迁移到 OpenClaw。
- OpenClaw 接收按钮和自由文本。
- OpenClaw 将结构化事件写入后端。
- Skill 权限限制为搜索、总结、推送、反馈处理。

验收：

- Python 自写 poller 可以关闭。
- Telegram 交互由 OpenClaw 处理。
- 后端仍然保存完整事实记录。

## 阶段 6：沉淀 Skill

目标：把推荐、反馈解释和复盘规范沉淀成可复用 Skill。

Skill 初版包括：

- 书籍推荐筛选规则。
- 推荐假设生成规则。
- 反馈原因解释规则。
- 多维画像更新规则。
- 每周复盘问题生成规则。

验收：

- prompt 硬编码减少。
- 推荐行为能通过 Skill 文件审查和迭代。
- Hermes 可提出 Skill 改进建议，但不自动上线。

## 阶段 7：30 天用户模型报告

目标：验证系统是否真正帮助用户更了解自己。

输出：

- 长期兴趣变化。
- 短期关注变化。
- 知识缺口地图。
- 阅读偏好画像。
- 反感模式。
- 行动阶段变化。
- 系统误解清单。
- 下月探索建议。

验收：

- 用户认为报告比初始用户说明书更准确。
- 报告能指出至少 3 个用户此前没有明确表达但认可的观察。

